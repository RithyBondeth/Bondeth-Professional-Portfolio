/**
 * Native Higgsedit composition. Build with: higgsedit build edit.js
 * Place the three public/previews images in this directory before building.
 * Output: a silent, 24-second 1280x720 H.264 showreel at 30fps.
 */
export default async ({ project, frame, text, rect, media }) => {
  const p = await project({ size: "1280x720", fps: 30, background: "#faf9f5" });
  const paper = "#faf9f5", ink = "#141413", coral = "#d97757", muted = "#7a786f";
  const type = (copy, x, y, size, color = ink, width = 1100, extra = {}) =>
    text(copy, { x, y, width, height: size * 1.5, fontFamily: "DM Sans",
      fontSize: size, fontWeight: 700, color, ...extra });
  const label = (copy, x, y, color = muted, width = 1100) =>
    type(copy, x, y, 17, color, width, { fontFamily: "Space Mono", fontWeight: 400 });
  const entrance = (delay = 0, distance = 28) => [
    { property: "opacity", from: 0, to: 1, at: delay, duration: 0.5, easing: "house" },
    { property: "offsetY", from: distance, to: 0, at: delay, duration: 0.7, easing: "house" },
  ];
  const scene = (name, at, dur, children, background = paper) => {
    p.compose([
      rect({ x: 0, y: 0, width: 1280, height: 720, fill: background }),
      frame({ x: 0, y: 0, width: 1280, height: 720, layout: "none",
        motion: { enter: { from: { opacity: 0, y: 12 }, duration: 0.35 },
          exit: { to: { opacity: 0, y: -8 }, duration: 0.25, anchor: "end" } } }, children),
    ], { at, dur, name });
  };
  const pixelB = (x, y, cell = 22) => {
    const rows = ["11110", "11001", "11001", "11110", "11001", "11001", "11110"];
    return rows.flatMap((row, r) => [...row].flatMap((v, c) => v === "1" ? [
      rect({ x: x + c * cell, y: y + r * cell, width: cell - 3, height: cell - 3,
        fill: r === 3 && c === 3 ? coral : ink,
        animate: entrance((r + c) * 0.035, 14) }),
    ] : []));
  };

  scene("01 — Introduction", 0, 4, [
    label("RITHY BONDETH / SELECTED WORK", 80, 68),
    ...pixelB(1035, 265),
    type("Ideas into", 80, 180, 100, ink, 920, { animate: entrance(0.15) }),
    type("working products.", 80, 285, 90, ink, 930, { animate: entrance(0.35) }),
    rect({ x: 84, y: 415, width: 210, height: 8, fill: coral,
      animate: [{ property: "scaleX", from: 0, to: 1, at: 0.5, duration: 0.6 }] }),
    type("Full Stack Developer & AI Engineer", 80, 485, 30, ink, 1100,
      { fontWeight: 400, animate: entrance(0.6) }),
    label("PHNOM PENH, CAMBODIA", 80, 625),
  ]);

  scene("02 — Capabilities", 4, 4, [
    label("FROM INTERFACE TO INTELLIGENCE", 80, 68),
    type("Built to work beautifully.", 80, 145, 64, ink, 1150, { animate: entrance(0.1) }),
    ...[
      ["01", "Web", "React / Next.js / TypeScript"],
      ["02", "Backend", "Python / FastAPI / PostgreSQL"],
      ["03", "AI systems", "LLMs / Agents / Workflows"],
    ].flatMap(([number, heading, detail], i) => [
      rect({ x: 80 + i * 380, y: 310, width: 350, height: 235, fill: "#f0eee6", radius: 8,
        animate: entrance(0.2 + i * 0.12) }),
      label(number, 104 + i * 380, 340, coral, 300),
      type(heading, 104 + i * 380, 395, 40, ink, 310, { animate: entrance(0.3 + i * 0.12) }),
      type(detail, 104 + i * 380, 470, 16, muted, 310, { fontWeight: 400,
        animate: entrance(0.4 + i * 0.12) }),
    ]),
    label("DESIGN / BUILD / SHIP", 80, 625),
  ]);

  const projects = [
    { at: 8, title: "Apsara Assistant", file: "apsara-assistant.png", category: "AI / CONVERSATIONS",
      description: "An AI sales assistant. Khmer and English.", stack: "Next.js / FastAPI / LLM APIs" },
    { at: 12, title: "Apsara Agentic", file: "apsara-agentic.png", category: "AI / AGENT WORKFLOWS",
      description: "The backend behind an agentic coding platform.", stack: "Python / Tool execution / Task orchestration" },
    { at: 16, title: "PDFlow", file: "pdfflow.png", category: "WEB / PRODUCTIVITY",
      description: "PDF creation and editing for Cambodian users.", stack: "Nuxt.js / FastAPI / Redis" },
  ];
  for (const item of projects) {
    const image = await p.add(new URL(item.file, import.meta.url).pathname);
    scene(item.title, item.at, 4, [
      label(item.category, 80, 45, coral),
      type(item.title, 80, 80, 48, ink, 1150, { animate: entrance(0.08) }),
      rect({ x: 80, y: 162, width: 1120, height: 416, fill: "#f0eee6", radius: 8 }),
      media({ file: image, x: 90, y: 172, width: 1100, height: 396, fit: "contain", radius: 5,
        animate: entrance(0.12, 18) }),
      type(item.description, 80, 600, 24, ink, 1120, { fontWeight: 400, animate: entrance(0.25) }),
      label(item.stack, 80, 650),
    ]);
  }

  scene("06 — Invitation", 20, 4, [
    label("HAVE SOMETHING IN MIND?", 80, 68, "#d6d3c9"),
    type("Let's build", 80, 175, 102, paper, 1100, { animate: entrance(0.15) }),
    type("something useful.", 80, 285, 94, paper, 1120, { animate: entrance(0.3) }),
    rect({ x: 80, y: 465, width: 370, height: 82, fill: coral, radius: 8,
      animate: entrance(0.4) }),
    type("bondeth.dev", 104, 480, 38, ink, 330, { animate: entrance(0.45) }),
    label("EXPLORE THE WORK / START A CONVERSATION", 80, 625, "#d6d3c9"),
  ], ink);

  // A continuous playhead connects the six scenes.
  p.compose(rect({ x: 0, y: 712, width: 1280, height: 8, fill: coral,
    animate: [{ property: "scaleX", from: 0, to: 1, duration: 24, easing: "linear" }] }),
    { at: 0, dur: 24, name: "Continuous progress" });
  await p.frame(2, "renders/portfolio-showreel-poster.png");
  await p.frame(10, "renders/project-preview.png");
  await p.frame(22, "renders/closing-preview.png");
  if (process.env.SHOWREEL_PREVIEW_ONLY !== "1") {
    await p.render("renders/portfolio-showreel.mp4", { bitrate: 2500000, concurrency: 2 });
  }
};

