/** Native Higgsedit, 32 seconds, 1920x1080 at 30 fps. */
export default async ({ project, frame, text, rect, media, path }) => {
const p = await project({ size: "1920x1080", fps: 30, background: "#141413" });
const C = { paper: "#faf9f5", ink: "#141413", coral: "#d97757", dim: "#a7a39a", line: "#33332f" };
const portrait = await p.add(new URL("portrait.webp", import.meta.url).pathname);
const soundtrack = await p.add(new URL("soundtrack.wav", import.meta.url).pathname);
p.cut(soundtrack, { at: 0, from: 0, dur: 32 });
const tween = (property, from, to, at = 0, duration = 0.65, easing = "house") =>
({ property, from, to, at, duration, easing });
const enter = (delay = 0, axis = "offsetY", distance = 55) =>
[tween("opacity", 0, 1, delay, 0.45), tween(axis, distance, 0, delay, 0.8)];
const type = (copy, x, y, size, width, color = C.paper, extra = {}) => text(copy, {
x, y, width, height: size * 1.5, fontFamily: "DM Sans", fontSize: size,
fontWeight: 700, color, lineHeight: 1.05, ...extra,
});
const mono = (copy, x, y, width = 1700, color = C.dim, extra = {}) =>
type(copy, x, y, 23, width, color, { fontFamily: "Space Mono", fontWeight: 400, ...extra });
const big = (copy, x, y, size, width, color = C.paper, extra = {}) =>
type(copy, x, y, size, width, color, { fontFamily: "Bebas Neue", fontWeight: 400,
letterSpacing: 1, ...extra });
const box = (x, y, w, h, fill, extra = {}) => rect({ x, y, width: w, height: h, fill, ...extra });
const line = (x1, y1, x2, y2, color, width = 2, extra = {}) => path({
d: `M ${x1} ${y1} L ${x2} ${y2}`, width: 1920, height: 1080,
stroke: { color, width }, ...extra,
});
const ring = (x, y, size, color, width = 2, extra = {}) => {
const r = size / 2, k = r * 0.552285;
return path({ x, y, width: size, height: size, fill: "transparent",
d: `M ${r} 0 C ${r+k} 0 ${size} ${r-k} ${size} ${r} C ${size} ${r+k} ${r+k} ${size} ${r} ${size} C ${r-k} ${size} 0 ${r+k} 0 ${r} C 0 ${r-k} ${r-k} 0 ${r} 0 Z`,
stroke: { color, width }, ...extra });
};
const burst = (x, y, size, color, dur, delay = 0) => frame({ x, y, width: size, height: size,
layout: "none", animate: [tween("rotation", -12, 24, 0, dur, "linear"), ...enter(delay)] },
Array.from({ length: 16 }, (_, i) => {
const a = i * Math.PI / 8, r = size / 2;
return path({ d: `M ${r + Math.cos(a)*r*0.38} ${r + Math.sin(a)*r*0.38} L ${r + Math.cos(a)*r} ${r + Math.sin(a)*r}`,
width: size, height: size, stroke: { color, width: size * 0.065 } });
}));
const chip = (copy, x, y, width, delay = 0, dark = true) => frame({ x, y, width, height: 62,
layout: "none", background: dark ? "#242422" : "#eeeae2", radius: 31,
animate: enter(delay) }, [type(copy, 22, 16, 25, width - 38, dark ? C.paper : C.ink, { fontWeight: 400 })]);
const pixel = (x, y, cell = 16, color = C.paper) => ["11110", "11001", "11001", "11110", "11001", "11001", "11110"]
.flatMap((row, r) => [...row].flatMap((v, c) => v === "1" ? [box(x+c*cell, y+r*cell, cell-3, cell-3,
r === 3 && c === 3 ? C.coral : color, { animate: enter((r+c)*0.025) })] : []));
const grid = (light = false) => Array.from({ length: 9 }, (_, i) =>
line(1040+i*110, 0, 590+i*110, 1080, light ? "#e9e5dc" : "#242422", 1));
const tape = (copy, dur, color = C.coral) => frame({ x: 0, y: 948, width: 1920, height: 66,
layout: "none", clip: true, background: color }, [
mono(`${copy}   /   ${copy}   /   ${copy}`, 36, 20, 3700, C.ink,
{ animate: [tween("offsetX", 0, -390, 0, dur, "linear")], fontSize: 25 }),
]);
const scene = (name, at, dur, nodes, light = false) => p.compose([
box(0, 0, 1920, 1080, light ? C.paper : C.ink), ...grid(light),
frame({ x: 0, y: 0, width: 1920, height: 1080, layout: "none", clip: true,
motion: { enter: { from: { opacity: 0, y: 18 }, duration: 0.18 },
exit: { to: { opacity: 0, y: -16 }, duration: 0.15, anchor: "end" } } }, nodes),
], { name, at, dur });
scene("01 / Meet Bondeth", 0, 4, [
mono("MEET THE PERSON BEHIND THE CODE", 110, 74, 1180, C.dim, { animate: enter(0.08) }),
...pixel(1700, 64),
ring(1120, 110, 870, "#4a3328", 65, { animate: [tween("scale", 0.86, 1.02, 0, 4, "linear")] }),
frame({ x: 1240, y: 193, width: 560, height: 670, layout: "none", clip: true, radius: 24,
motion: { enter: { from: { x: 160, scale: 0.9, opacity: 0 }, duration: 0.8, easing: "house" } } }, [
media({ file: portrait, x: 0, y: 0, width: 560, height: 670, fit: "cover",
animate: [tween("scale", 1, 1.06, 0, 4, "linear")] }),
]),
big("RITHY", 100, 205, 155, 1060, C.paper, { motion: { by: "character", from: { y: 110, opacity: 0 }, at: 0.1, duration: 0.5, overlap: 0.8, easing: "house" } }),
big("BONDETH", 96, 342, 230, 1130, C.coral, { motion: { by: "character", from: { y: 150, opacity: 0 }, at: 0.24, duration: 0.55, overlap: 0.85, easing: "house" } }),
type("Full Stack Developer", 110, 645, 47, 1080, C.paper, { animate: enter(0.65) }),
type("& AI Engineer", 110, 708, 47, 1080, C.paper, { animate: enter(0.8) }),
burst(1000, 695, 145, C.coral, 4, 0.7),
tape("PHNOM PENH, CAMBODIA  /  WEB · MOBILE · AI", 4),
]);
scene("02 / Foundation", 4, 5, [
mono("01 / THE FOUNDATION", 110, 74, 1100, "#81796f"),
big("CURIOUS BY NATURE.", 100, 155, 148, 1600, C.ink, { animate: enter(0.05) }),
big("ENGINEER BY TRAINING.", 100, 306, 132, 1680, C.coral, { animate: enter(0.22) }),
line(110, 507, 1800, 507, "#d5cfc4", 2),
frame({ x: 110, y: 558, width: 320, height: 285, layout: "none", background: C.ink, radius: 8,
motion: { enter: { from: { scale: 0.72, rotation: -8, opacity: 0 }, duration: 0.7, easing: "house" } } }, [
big("2020", 35, 20, 108, 250), mono("—", 130, 131, 70, C.coral), big("2024", 35, 163, 108, 250),
]),
type("Bachelor of Computer Science", 490, 570, 58, 1300, C.ink, { animate: enter(0.35) }),
type("Cambodia Academy of Digital Technology", 490, 655, 40, 1280, "#555148", { fontWeight: 400, animate: enter(0.5) }),
chip("CADT", 490, 748, 130, 0.6, false), chip("Techo Scholar", 640, 748, 235, 0.7, false),
burst(1570, 690, 145, C.coral, 5, 0.65),
tape("COMPUTER SCIENCE  /  SOFTWARE ENGINEERING  / CONTINUOUS LEARNING", 5),
], true);
scene("03 / Career journey", 9, 5, [
mono("02 / THE JOURNEY", 110, 74),
big("LEARN. BUILD. GROW.", 100, 162, 166, 1740, C.paper, { animate: enter(0.05) }),
type("From internship to production engineering.", 110, 365, 43, 1500, C.dim, { fontWeight: 400, animate: enter(0.2) }),
line(160, 526, 1710, 526, C.line, 3),
box(158, 518, 16, 16, C.coral, { radius: 8, animate: [tween("offsetX", 0, 1548, 0.3, 1.9)] }),
...[
["2022", "ALLWEB", "Web Developer", "Internship"],
["2023–24", "Freelance", "Web & mobile", "Team collaboration"],
["2024–25", "Mango-Byte", "Full Stack", "Developer"],
["2025–NOW", "DEBC", "Software", "Engineer"],
].flatMap(([year, org, role, second], i) => [
box(152+i*420, 518, 16, 16, i === 3 ? C.coral : C.paper, { radius: 8, animate: enter(0.3+i*0.18) }),
mono(year, 110+i*420, 577, 390, C.coral, { animate: enter(0.3+i*0.18) }),
type(org, 110+i*420, 630, 46, 390, C.paper, { animate: enter(0.4+i*0.18) }),
type(role, 110+i*420, 707, 29, 390, C.dim, { fontWeight: 400, animate: enter(0.5+i*0.18) }),
type(second, 110+i*420, 748, 29, 390, C.dim, { fontWeight: 400, animate: enter(0.6+i*0.18) }),
]),
mono("DEBC / DIGITAL ECONOMY AND BUSINESS COMMITTEE", 110, 851, 1710, C.dim, { fontSize: 20, animate: enter(1.1) }),
tape("REAL TEAMS  /  REAL RESPONSIBILITIES  /  PRODUCTION APPLICATIONS", 5),
]);
scene("04 / Full stack", 14, 5, [
mono("03 / THE SKILLS", 110, 74, 1400, "#81796f"),
big("FRONT TO BACK.", 100, 153, 162, 1700, C.ink, { animate: enter(0.05) }),
type("Interfaces. APIs. Data.", 110, 354, 49, 1500, C.ink, { animate: enter(0.2) }),
chip("React", 110, 484, 145, 0.35, false), chip("Next.js", 275, 484, 160, 0.4, false),
chip("TypeScript", 455, 484, 215, 0.45, false),
chip("Vue / Nuxt", 110, 565, 220, 0.5, false), chip("Tailwind", 350, 565, 190, 0.55, false),
chip("Python", 110, 674, 155, 0.6, false), chip("FastAPI", 285, 674, 175, 0.65, false),
chip("NestJS", 480, 674, 160, 0.7, false),
chip("PostgreSQL", 110, 755, 240, 0.75, false), chip("Redis", 370, 755, 145, 0.8, false),
frame({ x: 880, y: 450, width: 920, height: 396, layout: "none", background: C.ink, radius: 12,
motion: { enter: { from: { x: 120, rotation: 3, opacity: 0 }, duration: 0.85, easing: "house" },
timeline: { from: { y: 0 }, to: { y: -12 }, at: 1, duration: 3.5, easing: "linear" } } }, [
...[C.coral, "#e6c994", "#7a9d81"].map((color, i) => box(28+i*30, 25, 13, 13, color, { radius: 7 })),
mono("profile.ts", 137, 19, 500, C.dim, { fontSize: 19 }),
mono("const developer = {", 40, 94, 860, C.coral, { animate: enter(0.45), fontSize: 28 }),
mono('  frontend: "thoughtful interfaces",', 40, 157, 860, C.paper, { animate: enter(0.6), fontSize: 25 }),
mono('  backend:  "reliable systems",', 40, 218, 860, C.paper, { animate: enter(0.75), fontSize: 25 }),
mono('  approach: "build end to end"', 40, 279, 860, C.paper, { animate: enter(0.9), fontSize: 25 }),
mono("};", 40, 335, 860, C.coral, { animate: enter(1.0), fontSize: 28 }),
]),
tape("FRONTEND  →  BACKEND  →  DATABASE  →  PRODUCTION", 5),
], true);
scene("05 / Mobile and delivery", 19, 4, [
mono("04 / BEYOND THE BROWSER", 110, 74),
big("BUILD IT.", 100, 164, 170, 1020, C.paper, { animate: enter(0.05) }),
big("SHIP IT.", 100, 326, 170, 1020, C.coral, { animate: enter(0.18) }),
type("Mobile experiences & deployment workflows.", 110, 558, 34, 1050, C.dim, { fontWeight: 400, animate: enter(0.35) }),
chip("Flutter", 110, 656, 170, 0.45), chip("Docker", 300, 656, 170, 0.52),
chip("GitHub Actions", 490, 656, 265, 0.59),
chip("Linux", 110, 742, 145, 0.66), chip("Nginx", 275, 742, 150, 0.73),
chip("Cloudflare", 445, 742, 210, 0.8),
ring(1070, 175, 670, "#3c3028", 2, { animate: [tween("scale", 0.94, 1.05, 0, 4, "linear")] }),
frame({ x: 1250, y: 233, width: 300, height: 565, layout: "none", background: "#242422", radius: 42,
motion: { enter: { from: { y: 180, rotation: -12, opacity: 0 }, duration: 0.8, easing: "house" },
timeline: { to: { rotation: 2, y: -16 }, at: 1, duration: 2.8, easing: "smooth" } } }, [
box(14, 14, 272, 537, C.paper, { radius: 30 }), box(100, 29, 100, 22, C.ink, { radius: 12 }),
big("HELLO.", 38, 115, 75, 240, C.ink), box(38, 217, 220, 9, C.coral),
...[0, 1, 2].flatMap(i => [box(38, 275+i*61, 38, 38, "#e9e3d9", { radius: 8 }),
box(94, 281+i*61, 155, 8, "#d3cec4", { radius: 4 }), box(94, 297+i*61, 109, 6, "#e4dfd6", { radius: 3 })]),
box(38, 470, 220, 43, C.coral, { radius: 8 }), mono("Flutter", 90, 482, 150, C.ink, { fontSize: 17 }),
]),
burst(1640, 692, 130, C.coral, 4, 0.5),
tape("MOBILE  /  CI & CD  /  CLOUD  /  DELIVERY", 4),
]);
const aiNodes = [[1060, 490, "LLMs", 185], [1450, 490, "Tools", 185], [1240, 705, "Agents", 200], [1240, 280, "Context", 210]];
scene("06 / AI engineering", 23, 5, [
mono("05 / INTELLIGENT SYSTEMS", 110, 74),
big("THINK IN", 100, 165, 148, 1030, C.paper, { animate: enter(0.05) }),
big("SYSTEMS.", 100, 306, 180, 1030, C.coral, { animate: enter(0.18) }),
type("Connect models, tools, and workflows.", 110, 538, 34, 1030, C.dim, { fontWeight: 400, animate: enter(0.35) }),
chip("OpenAI", 110, 642, 170, 0.45), chip("Anthropic", 300, 642, 205, 0.52), chip("Gemini", 525, 642, 160, 0.59),
chip("LangChain", 110, 724, 220, 0.66), chip("LangGraph", 350, 724, 220, 0.73), chip("Ollama", 590, 724, 160, 0.8),
ring(1100, 235, 580, "#43382f", 2), ring(1190, 325, 400, "#2b2b28", 1),
...[[1330, 340, 1150, 520], [1330, 340, 1535, 520], [1150, 520, 1340, 735], [1535, 520, 1340, 735]].map(
([x1,y1,x2,y2], i) => line(x1,y1,x2,y2, "#8b6751", 3, { animate: [tween("opacity", 0, 1, 0.4+i*0.1, 0.5)] })),
...aiNodes.map(([x,y,copy,width], i) => frame({ x, y, width, height: 72, layout: "none", background: "#2a2925", radius: 36,
motion: { enter: { from: { scale: 0.6, opacity: 0 }, at: 0.5+i*0.12, duration: 0.6, easing: "house" } } }, [
type(copy, 25, 20, 28, width-45, C.paper, { align: "center", fontWeight: 400 }),
])),
...[0, 1, 2].map(i => box(1326, 351, 12, 12, C.coral, { radius: 6,
animate: [tween("offsetX", 0, -180, 1+i*0.8, 0.75, "linear"), tween("offsetY", 0, 170, 1+i*0.8, 0.75, "linear"),
{ property: "opacity", keyframes: [{at:0,value:0},{at:1+i*0.8,value:1},{at:1.7+i*0.8,value:1},{at:1.75+i*0.8,value:0}], easing: "hold" }] })),
burst(1570, 742, 98, C.coral, 5, 0.8),
tape("LLM INTEGRATIONS  /  AGENT ORCHESTRATION  /  AI WORKFLOWS", 5),
]);
scene("07 / Invitation", 28, 4, [
mono("LET'S MAKE SOMETHING THAT MATTERS", 110, 74, 1600, "#81796f", { animate: enter(0.05) }),
...pixel(1680, 63, 17, C.ink),
big("YOUR NEXT", 100, 177, 186, 1700, C.ink, { motion: { by: "word", from: { opacity: 0, y: 110 }, duration: 0.6, overlap: 0.7, easing: "house" } }),
big("IDEA. BUILT.", 100, 368, 212, 1690, C.coral, { animate: enter(0.2) }),
type("Rithy Bondeth / Full Stack Developer & AI Engineer", 110, 666, 36, 1680, C.ink, { fontWeight: 400, animate: enter(0.45) }),
frame({ x: 110, y: 761, width: 500, height: 99, layout: "none", background: C.ink, radius: 12,
motion: { enter: { from: { scale: 0.9, opacity: 0 }, at: 0.5, duration: 0.5, easing: "house" } } }, [
type("bondeth.dev", 36, 25, 43, 380), path({x:412,y:29,width:44,height:44,d:"M 6 36 L 36 6 M 9 6 L 36 6 L 36 33",stroke:{color:C.coral,width:3,cap:"round"}}),
]),
burst(1460, 680, 165, C.ink, 4, 0.65), tape("START A CONVERSATION  /  BONDETH.DEV", 4),
], true);
p.compose([
mono("BONDETH / BACKGROUND & SKILLS", 110, 1043, 1100, C.dim, { fontSize: 15 }),
...[0, 1, 2, 3, 4, 5, 6].map(i => box(1590+i*31, 1048, 18, 3, "#6e655a")),
box(1590, 1046, 18, 7, C.coral, { animate: [{ property: "offsetX", keyframes:
[0,4,9,14,19,23,28].map((at,i) => ({at,value:i*31,easing:"hold"})) }] }),
], { name: "Chapter rail", at: 0, dur: 32 });
await p.frame(2.5, "renders/portfolio-intro-v2-poster.png");
if (process.env.SHOWREEL_PREVIEW_ONLY !== "1") {
await p.render("renders/portfolio-intro-v2.mp4", { bitrate: 4500000, concurrency: 2 });
}
};

