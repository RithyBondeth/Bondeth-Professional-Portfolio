"""Original, deterministic 32-second instrumental; no samples or external music."""
import math
import os
import random
import struct
import wave
from pathlib import Path

RATE = 44100
DURATION = int(os.environ.get("SHOWREEL_DURATION", "32"))
rng = random.Random(20261001)
samples = [0.0] * (RATE * DURATION)


def add(start, duration, synth, gain=1.0):
    offset = int(start * RATE)
    for n in range(min(int(duration * RATE), len(samples) - offset)):
        samples[offset + n] += synth(n / RATE) * gain


def hz(note):
    return 440 * 2 ** ((note - 69) / 12)


# Warm Cmaj7, Am7, Fmaj7, G6 progression with a soft 120 bpm pulse.
chords = [(48, 52, 55, 59), (45, 48, 52, 55), (41, 45, 48, 52), (43, 47, 50, 52)]
for bar in range(math.ceil(DURATION / 2)):
    chord = chords[(bar // 2) % 4]
    for note in chord:
        f = hz(note + 12)
        add(bar * 2, 2.2, lambda t, f=f: (
            math.sin(2 * math.pi * f * t) + 0.2 * math.sin(2 * math.pi * f * 2.003 * t)
        ) * min(1, t / 0.18) * math.exp(-t / 1.2), 0.033)
    for beat in range(4):
        time = bar * 2 + beat * 0.5
        f = hz(chord[0] - 12)
        add(time, 0.4, lambda t, f=f: math.sin(2 * math.pi * f * t) * math.exp(-t * 10), 0.10)
        add(time, 0.22, lambda t: math.sin(2 * math.pi * (43 * t + 55 * (1-math.exp(-t*23))/23)) * math.exp(-t*22), 0.16)
        for subdivision in range(2):
            f = hz(chord[(beat + subdivision) % 4] + 24)
            add(time + subdivision * 0.25, 0.30, lambda t, f=f: (
                math.sin(2 * math.pi * f * t) + 0.15 * math.sin(2 * math.pi * 2 * f * t)
            ) * math.exp(-t * 18) * min(1, t / 0.007), 0.048)
        noise = [rng.uniform(-1, 1) for _ in range(int(RATE * 0.055))]
        add(time + 0.25, 0.055, lambda t, noise=noise: noise[min(len(noise)-1, int(t*RATE))] * math.exp(-t*75), 0.016)

for time in map(float, os.environ.get("SHOWREEL_AUDIO_CUES", "4,9,14,19,23,28").split(",")):
    add(time - 0.16, 0.35, lambda t: math.sin(2 * math.pi * (240*t + 950*t*t)) * math.sin(math.pi*t/0.35)**2, 0.025)

with wave.open(str(Path(__file__).with_name(os.environ.get("SHOWREEL_AUDIO_FILE", "soundtrack.wav"))), "wb") as out:
    out.setnchannels(2)
    out.setsampwidth(2)
    out.setframerate(RATE)
    pcm = bytearray()
    for i, value in enumerate(samples):
        t = i / RATE
        fade = min(1, t / 0.6, (DURATION - t) / 1.5)
        sample = int(math.tanh(value * 1.4) * fade * 23000)
        pcm.extend(struct.pack("<hh", sample, sample))
    out.writeframes(pcm)

