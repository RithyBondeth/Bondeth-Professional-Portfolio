/** 36-second native composition. Every motion track is rendered at 60fps. */
export default async ({ project, frame, text, rect, media, path }) => {
  const p = await project({ size: "1920x1080", fps: 60, background: "#141413" });
  const C = { ink: "#141413", paper: "#faf9f5", coral: "#d97757", dim: "#aaa69c" };
  const file = name => new URL(`assets/${name}`, import.meta.url).pathname;
  const portrait = await p.add(file("portrait.webp"));
  const shots = {};
  for (const name of ["talent", "assistant", "notch"]) shots[name] = await p.add(file(`${name}.png`));
  const tech = [
    ["react", "React", 315, 408], ["nextdotjs", "Next.js", 625, 408],
    ["typescript", "TypeScript", 935, 408], ["nestjs", "NestJS", 1245, 408],
    ["postgresql", "PostgreSQL", 1555, 408], ["python", "Python", 315, 688],
    ["fastapi", "FastAPI", 625, 688], ["flutter", "Flutter", 935, 688],
    ["docker", "Docker", 1245, 688], ["swift", "Swift", 1555, 688],
  ];
  const icons = {};
  for (const [slug] of tech) icons[slug] = await p.add(file(`${slug}.png`));
  const music = await p.add(new URL("soundtrack-v3.wav", import.meta.url).pathname);
  p.cut(music, { at: 0, dur: 36 });
  const k = (at, value, easing = "house") => ({ at, value, easing });
  const track = (property, keyframes) => ({ property, keyframes });
  const t = (property, from, to, at = 0, duration = 0.7, easing = "house") => ({ property, from, to, at, duration, easing });
  // Merge entrance and exit schedules into one native track per property.
  const clean = extra => {
    if(!extra.animate) return extra;
    const channels = new Map();
    for(const a of extra.animate) {
      const keys = a.keyframes ?? [k(a.at??0,a.from,a.easing??"house"),k((a.at??0)+(a.duration??.7),a.to)];
      const old = channels.get(a.property) ?? [];
      old.push(...keys.filter(key=>old.length===0||key.at!==0));
      channels.set(a.property,old);
    }
    return {...extra,animate:[...channels].map(([property,keys])=>track(property,
      [...new Map(keys.map(key=>[key.at,key])).values()].sort((a,b)=>a.at-b.at)))};
  };
  const fade = (start, end) => track("opacity", [k(0,0),k(start,1),k(end-0.2,1),k(end,0)]);
  const R = (x,y,w,h,fill,extra={}) => rect({x,y,width:w,height:h,fill,...clean(extra)});
  const T = (copy,x,y,size,w=1700,color=C.paper,extra={}) => text(copy, { x,y,width:w,height:size*2.8,
    fontFamily:"DM Sans",fontSize:size,fontWeight:700,color,lineHeight:1.05,...clean(extra) });
  const B = (copy,x,y,size,w=1700,color=C.paper,extra={}) => T(copy,x,y,size,w,color,
    {fontFamily:"Bebas Neue",fontWeight:400,letterSpacing:1,...extra});
  const M = (copy,x,y,w=1700,color=C.dim,extra={}) => T(copy,x,y,22,w,color,
    {fontFamily:"Space Mono",fontWeight:400,...extra});
  const F = (name,x,y,w,h,children,extra={}) => frame({name,x,y,width:w,height:h,layout:"none",...clean(extra)},children);
  const reveal = (delay=0,from="bottom") => ({reveal:{from,at:delay,duration:0.75,easing:"house"}});
  const moveIn = (at=0,x=0,y=65) => [t("opacity",0,1,at,.4),t("offsetX",x,0,at,.75),t("offsetY",y,0,at,.75)];
  const line = (x1,y1,x2,y2,color,width=2,extra={}) => path({d:`M ${x1} ${y1} L ${x2} ${y2}`,
    width:1920,height:1080,stroke:{color,width},...extra});
  const circle = (x,y,size,fill,extra={}) => R(x,y,size,size,fill,{radius:size/2,...extra});
  const arrow = (x,y,color=C.coral) => path({x,y,width:48,height:48,d:"M 6 40 L 40 6 M 8 6 L 40 6 L 40 38",stroke:{color,width:4,cap:"round"}});
  const icon = (slug,x,y,size,extra={}) => media({file:icons[slug],x,y,width:size,height:size,fit:"contain",...clean(extra)});
  const compose = (nodes,at,dur,name) => p.compose(nodes,{at,dur,name});
  const exit = (end,x=0,y=-35) => [track("opacity",[k(0,1),k(end-.4,1),k(end,0)]),
    track("offsetX",[k(0,0),k(end-.55,0),k(end,x)]),track("offsetY",[k(0,0),k(end-.55,0),k(end,y)])];

  // The background is persistent. Foreground objects carry the changes of scene.
  compose([
    R(0,0,1920,1080,C.ink),
    ...Array.from({length:8},(_,i)=>line(1160+i*110,0,630+i*110,1080,"#23231f",1,
      {animate:[t("offsetX",0,-55,0,36,"linear")]})),
    M("BONDETH / FROM SKILL TO SYSTEM",100,1038,1200,C.dim,{fontSize:16}),
    R(1550,1048,265,3,"#444038"),R(1550,1048,265,3,C.coral,{animate:[t("scaleX",0,1,0,36,"linear")]}),
  ],0,36,"Persistent stage");

  // 0–5: exact hero portrait, layered typography and a travelling coral shutter.
  compose([
    F("Portrait stage",1170,90,680,910,[
      R(0,0,680,910,C.paper,{radius:28}),
      B("BUILD",35,45,180,630,"#ded9cf",{animate:[t("offsetY",45,-35,0,5,"linear")]}),
      B("CREATE",20,255,160,650,"#e9e2d8"),
      media({file:portrait,x:10,y:35,width:660,height:806,fit:"contain",
        animate:[t("offsetY",130,0,.1,.9),t("scale",.96,1.035,.1,4.8)]}),
      R(32,823,616,56,C.coral,{radius:8}),M("PHNOM PENH / CAMBODIA",58,840,560,C.ink,{fontSize:21}),
    ],{clip:true,animate:[...moveIn(.05,170,0),...exit(5.2,950,0)]}),
    M("FULL STACK / AI ENGINEERING",110,78,1020,C.dim,{animate:moveIn(.1)}),
    F("First name",100,195,1030,180,[B("RITHY",0,0,165,1030,C.paper,
      {motion:{by:"character",from:{y:155,opacity:0},at:.05,duration:.5,overlap:.85,easing:"house"}})],{clip:true,animate:exit(5,-850,0)}),
    F("Family name",98,373,1080,250,[B("BONDETH",0,0,238,1070,C.coral,
      {motion:{by:"character",from:{y:205,opacity:0},at:.18,duration:.55,overlap:.88,easing:"house"}})],{clip:true,animate:exit(5,-1000,0)}),
    T("Full Stack Developer",110,710,48,1080,C.paper,{animate:[...moveIn(.55),...exit(5)]}),
    T("& AI Engineer",110,779,48,1080,C.paper,{animate:[...moveIn(.7),...exit(5)]}),
  ],0,5.2,"01 / Identity");
  compose(R(-1920,0,1920,1080,C.coral,{animate:[t("offsetX",0,3840,0,.72,"house")]}),4.65,.72,"Coral shutter");

  // 5–9: large experience statement; technology silhouettes preview the next beat.
  compose(F("Experience",0,0,1920,1080,[
    M("EXPERIENCE THAT CONNECTS THE WHOLE STACK",110,84,1660,C.dim,{animate:moveIn(.15)}),
    B("3+",95,177,510,770,C.coral,{animate:moveIn(.05,-180,0)}),
    B("YEARS",116,724,116,790,C.paper,{animate:moveIn(.3)}),
    T("Full Stack",930,280,85,860,C.paper,{animate:moveIn(.2,120,0)}),
    T("Development",930,380,85,880,C.paper,{animate:moveIn(.35,120,0)}),
    T("Web. Mobile. AI.",936,546,43,850,C.dim,{fontWeight:400,animate:moveIn(.5)}),
    M("FROM INTERFACE TO API TO PRODUCTION",936,662,830,C.coral,{fontSize:20,animate:moveIn(.65)}),
    M("FREELANCE / MANGO-BYTE / DEBC",936,735,840,C.dim,{fontSize:20,animate:moveIn(.75)}),
  ],{animate:exit(4.5,0,-260)}),4.95,4.5,"02 / Experience");
  // A zooming pixel bridge makes the experience scene become the toolbox stage.
  compose(F("Pixel bridge",850,480,180,180,[R(0,0,180,180,C.paper),R(52,52,76,76,C.coral)],{
    animate:[track("scale",[k(0,.02),k(.32,.7),k(.67,13.5)]),track("rotation",[k(0,-35),k(.67,0)]),
      track("opacity",[k(0,0),k(.06,1),k(.54,1),k(.7,0)])],origin:"center"}),8.52,.7,"Pixel zoom transition");

  // 9–14: real technology icons arrive from depth and drift along sampled arcs.
  compose([
    B("MY TOOLBOX.",110,115,142,1700,C.paper,{animate:[...moveIn(.08),...exit(5.6,-700,0)]}),
    M("THE TOOLS CHANGE. THE GOAL IS USEFUL SOFTWARE.",115,295,1660,C.dim,
      {animate:[...moveIn(.24),...exit(5.6)]}),
  ],8.85,5.6,"03 / Technologies");
  for (let i=0;i<tech.length;i++) {
    const [slug,label,x,y]=tech[i];
    if(slug==="nextdotjs") continue;
    const sway=Array.from({length:13},(_,j)=>k(.95+j*.245,Math.sin(j*.55+i)*11,"smooth"));
    compose(F(`Icon / ${label}`,x-85,y,170,204,[
      R(0,0,170,170,C.paper,{radius:28}),icon(slug,40,39,90),
      M(label,-28,184,226,C.paper,{fontSize:21,align:"center"}),
    ],{animate:[
      track("opacity",[k(0,0),k(.12+i*.045,0),k(.55+i*.045,1),k(4.35,1),k(4.9,0)]),
      track("scale",[k(0,.35),k(.75+i*.045,1),k(4.25,1),k(4.9,.35)]),
      track("offsetX",[k(0,(i%2?1:-1)*240),k(.85+i*.045,0),k(4.2,0),k(4.9,(960-x)*.65)]),
      track("offsetY",[k(0,150),...sway,k(4.2,0),k(4.9,580-y)]),
      track("rotation",[k(0,(i%2?1:-1)*22),k(.85,0),k(4.3,0),k(4.9,(i%2?1:-1)*35)]),
    ]}),9,5,"Technology constellation");
  }

  // This is ONE persistent object: Next.js tile expands into the Apsara Talent browser.
  compose(F("Next.js becomes Apsara Talent",800,245,170,170,[
    R(0,0,1040,650,C.paper,{radius:22}),
    icon("nextdotjs",40,40,90,{animate:[track("opacity",[k(0,1),k(4.45,1),k(4.82,0)])]}),
    M("Next.js",-25,185,220,C.paper,{fontSize:21,align:"center",animate:[track("opacity",[k(0,1),k(4.4,1),k(4.7,0)])]}),
    F("Browser contents",0,0,1040,650,[
      ...[C.coral,"#c9b48f","#799178"].map((color,i)=>circle(25+i*29,22,12,color)),
      M("talent.apsara.social",160,17,820,"#757065",{fontSize:17}),
      media({file:shots.talent,x:20,y:80,width:1000,height:528,fit:"contain",radius:10}),
      R(20,618,1000,2,"#ddd7cd"),
    ],{animate:[track("opacity",[k(0,0),k(4.68,0),k(5.15,1)])]}),
  ],{clip:true,animate:[
    track("width",[k(0,170),k(4.4,170),k(5.3,1040)]),track("height",[k(0,170),k(4.4,170),k(5.3,650)]),
    track("offsetX",[k(0,-260),k(4.4,-260),k(5.3,0),k(10.4,0),k(11.25,-1600)]),
    track("offsetY",[k(0,163),k(4.4,163),k(5.3,0)]),
    track("rotation",[k(0,-16),k(.7,0),k(4.35,0),k(4.72,8),k(5.3,0)]),
    track("opacity",[k(0,0),k(.65,1),k(10.85,1),k(11.25,0)]),
  ]}),9,11.3,"Continuous icon-to-project transformation");

  const story=(name,at,title,problem,decision,result,slug)=>compose(F(name,0,0,760,1000,[
    M("CASE STUDY / ENGINEERING IN PRACTICE",110,88,1680,C.dim,{fontSize:19,animate:moveIn(.2)}),
    B(title,100,190,103,680,C.paper,{animate:moveIn(.22,-90,0)}),
    M("THE PROBLEM",112,369,630,C.coral,{fontSize:18,animate:moveIn(.4)}),
    T(problem,110,414,33,620,C.paper,{fontWeight:400,animate:moveIn(.5)}),
    M("THE DECISION",112,556,630,C.coral,{fontSize:18,animate:moveIn(.65)}),
    T(decision,110,598,30,625,C.dim,{fontWeight:400,animate:moveIn(.75)}),
    R(110,744,630,124,"#25231f",{radius:12,animate:moveIn(.88)}),
    T(result,137,771,35,580,C.paper,{animate:moveIn(1)}),
    M(`bondeth.dev/en/projects/${slug}`,112,930,1690,C.dim,{fontSize:17,animate:moveIn(1.1)}),
  ],{animate:exit(6.15,-400,0)}),at,6.15,name);
  story("04 / Apsara Talent",14,"APSARA TALENT","Match people on meaning, not exact keywords.",
    "Semantic matching with pgvector; a NestJS service architecture.","7 backend services","apsara-talent");

  const browser=(name,at,shot,slug,iconSlug,height)=>compose(F(name,800,245,1040,650,[
    R(0,0,1040,650,C.paper,{radius:22}),
    ...[C.coral,"#c9b48f","#799178"].map((color,i)=>circle(25+i*29,22,12,color)),
    M(slug,160,17,820,"#757065",{fontSize:17}),
    media({file:shot,x:20,y:80+(528-height)/2,width:1000,height,fit:"contain",radius:10}),
    R(20,618,1000,2,"#ddd7cd"),
    F("Originating technology icon",418,238,170,170,[R(0,0,170,170,C.paper,{radius:28}),icon(iconSlug,40,40,90)],
      {animate:[track("scale",[k(0,1.65),k(.65,.65)]),track("opacity",[k(0,1),k(.36,1),k(.72,0)])]}),
  ],{clip:true,animate:[
    track("offsetX",[k(0,1220),k(.8,0),k(5.55,0),k(6.15,-1450)]),
    track("scale",[k(0,.7),k(.8,1),k(5.55,1),k(6.15,.9)]),
    track("rotation",[k(0,8),k(.8,0),k(5.55,0),k(6.15,-6)]),
    track("opacity",[k(0,0),k(.12,1),k(5.75,1),k(6.15,0)]),
  ]}),at,6.15,name);
  browser("Python to Apsara Assistant",19.85,shots.assistant,"assistant.apsara.social","python",448);
  story("05 / Apsara Assistant",20,"APSARA ASSISTANT","Customers mix Khmer, English, and romanized Khmer.",
    "Decide language per message; ground replies in the shop catalogue.","3 language modes / 2 channels","apsara-assistant");
  browser("Swift to Bondex Notch",25.85,shots.notch,"bondex-notch.bondeth.site","swift",528);
  story("06 / Bondex Notch",26,"BONDEX NOTCH","An always-visible utility needs to stay quiet and efficient.",
    "Move equaliser animation from SwiftUI to Core Animation.","12–14% to 3% CPU*","bondex-notch");
  compose(M("*Measured while music plays; see the case study.",810,930,1030,C.dim,{fontSize:17,
    animate:[...moveIn(1),...exit(6)]}),26,6,"Metric context");
  // Diagonal shutters mask the moment between two moving browser panels.
  for(const at of [19.65,25.65])compose(F("Diagonal project shutter",0,0,1920,1080,[
    R(-1450,-180,560,1440,C.coral),R(-2070,-180,560,1440,"#ead0bd"),
  ],{animate:[t("offsetX",0,4400,0,.72),t("rotation",-11,-11,0,.72)]}),at,.72,"Project transition");

  // 32–36: a fan of the three real previews shrinks into the final invitation.
  compose([
    ...["talent","assistant","notch"].map((name,i)=>F(`Project fan / ${name}`,1170+i*70,282+i*75,510,315,[
      R(0,0,510,315,C.paper,{radius:14}),media({file:shots[name],x:10,y:30,width:490,height:260,fit:"cover",radius:10}),
    ],{clip:true,animate:[t("offsetX",500,0,.1+i*.12,.85),t("rotation",0,(i-1)*9,.1+i*.12,.85),
      t("scale",1.15,1,.1+i*.12,.85),t("opacity",0,1,.1+i*.12,.5)]})),
    M("TURN THE RIGHT TOOLS INTO THE RIGHT PRODUCT.",110,90,1670,C.dim,{animate:moveIn(.15)}),
    B("YOUR NEXT",100,222,162,1090,C.paper,{animate:moveIn(.2,-110,0)}),
    B("IDEA. BUILT.",100,399,192,1090,C.coral,{animate:moveIn(.35,-150,0)}),
    T("Read the thinking behind the work.",110,663,39,1080,C.paper,{fontWeight:400,animate:moveIn(.55)}),
    F("Call to action",110,774,520,106,[R(0,0,520,106,C.coral,{radius:12}),
      T("bondeth.dev",35,26,46,400,C.ink),arrow(440,28,C.ink)],{animate:moveIn(.7)}),
    M("FULL STACK DEVELOPER & AI ENGINEER",110,934,1640,C.dim,{fontSize:19,animate:moveIn(.85)}),
  ],31.85,4.15,"07 / Explore the case studies");
  await p.frame(2.5,"renders/portfolio-showreel-v3-poster.png");
  if(process.env.SHOWREEL_PREVIEW_ONLY!=="1")await p.render("renders/portfolio-showreel-v3-master.mp4",{concurrency:2});
};

