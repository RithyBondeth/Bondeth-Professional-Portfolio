/** 30-second cinematic showreel. All native motion is sampled at 120 fps. */
export default async ({ project, frame, text, rect, media, path }) => {
  const p = await project({ size: "1920x1080", fps: 120, background: "#070b14" });
  const C = {
    bg: "#070b14", white: "#f6f8f6", muted: "#9aabc3", cyan: "#5ce5df",
    blue: "#7198ff", coral: "#ff9073", line: "#1a2b3f",
  };
  const file = name => new URL(`assets/${name}`, import.meta.url).pathname;
  const portrait = await p.add(file("portrait.webp"));
  const shots = {};
  for (const name of ["talent", "assistant", "notch"]) shots[name] = await p.add(file(`${name}.png`));
  const icons = {};
  for (const slug of ["react", "nextdotjs", "typescript", "nestjs", "postgresql",
    "python", "fastapi", "flutter", "docker", "swift"]) icons[slug] = await p.add(file(`${slug}.png`));
  const music = await p.add(new URL("soundtrack-v4.wav", import.meta.url).pathname);
  p.cut(music, { at: 0, dur: 30 });

  const k = (at, value, easing = "house") => ({ at, value, easing });
  const a = (property, keyframes) => ({ property, keyframes });
  const t = (property, from, to, at, duration, easing = "house") =>
    ({ property, from, to, at, duration, easing });
  const merge = extra => {
    if (!extra.animate) return extra;
    const map = new Map();
    for (const item of extra.animate) {
      const keys = item.keyframes ?? [k(item.at ?? 0, item.from, item.easing),
        k((item.at ?? 0) + (item.duration ?? 0.6), item.to)];
      const existing = map.get(item.property) ?? [];
      existing.push(...keys.filter(key => existing.length === 0 || key.at !== 0));
      map.set(item.property, existing);
    }
    return { ...extra, animate: [...map].map(([property, keys]) => a(property,
      [...new Map(keys.map(key => [key.at, key])).values()].sort((x, y) => x.at - y.at))) };
  };
  const R = (x, y, width, height, fill, extra = {}) => rect({ x, y, width, height, fill, ...merge(extra) });
  const F = (name, x, y, width, height, children, extra = {}) => frame(
    { name, x, y, width, height, layout: "none", ...merge(extra) }, children);
  const T = (copy, x, y, size, width = 1700, color = C.white, extra = {}) => text(copy,
    { x, y, width, height: size * 2.4, fontFamily: "DM Sans", fontSize: size,
      fontWeight: 700, lineHeight: 1.02, color, ...merge(extra) });
  const B = (copy, x, y, size, width = 1700, color = C.white, extra = {}) => T(copy,
    x, y, size, width, color, { fontFamily: "Bebas Neue", fontWeight: 400,
      letterSpacing: 1, ...extra });
  const M = (copy, x, y, width = 1700, color = C.muted, extra = {}) => T(copy,
    x, y, 20, width, color, { fontFamily: "Space Mono", fontWeight: 400, ...extra });
  const I = (slug, x, y, size, extra = {}) => media({ file: icons[slug], x, y,
    width: size, height: size, fit: "contain", ...merge(extra) });
  const L = (x1, y1, x2, y2, color = C.line, width = 1, extra = {}) => path({
    d: `M ${x1} ${y1} L ${x2} ${y2}`, width: 1920, height: 1080,
    stroke: { color, width }, ...extra,
  });
  const show = (nodes, at, dur, name) => p.compose(nodes, { at, dur, name });
  const rise = (at = 0, fromY = 95) => [t("opacity", 0, 1, at, 0.42),
    t("offsetY", fromY, 0, at, 0.75)];
  const exit = (time, x = -350) => [a("opacity", [k(0, 1), k(time - 0.35, 1), k(time, 0)]),
    a("offsetX", [k(0, 0), k(time - 0.5, 0), k(time, x)])];

  // A moving, gridded black stage runs through the entire cut.
  show([
    R(0, 0, 1920, 1080, C.bg),
    ...Array.from({ length: 11 }, (_, i) => L(i * 192, 0, i * 192, 1080)),
    ...Array.from({ length: 7 }, (_, i) => L(0, i * 180, 1920, i * 180)),
    ...Array.from({ length: 8 }, (_, i) => R(120 + i * 250, 145 + (i % 3) * 300,
      7, 7, C.cyan, { radius: 4, opacity: 0.36,
        animate: [a("offsetY", [k(0, 0), k(15, -25), k(30, 0)])] })),
    M("RITHY BONDETH / BUILDING USEFUL SYSTEMS", 94, 1015, 1320, C.muted,
      { fontSize: 15 }),
    R(1470, 1025, 350, 3, C.line),
    R(1470, 1025, 350, 3, C.cyan, { animate: [t("scaleX", 0, 1, 0, 30, "linear")] }),
  ], 0, 30, "Persistent cinematic stage");

  // Identity. The real hero portrait moves against large editorial type.
  show([
    R(1055, 62, 798, 960, "#0b1929", { radius: 28,
      animate: [t("offsetX", 250, 0, 0, 0.75)] }),
    R(1110, 106, 10, 805, C.cyan, { radius: 5,
      animate: [t("scaleY", 0, 1, 0.32, 1.05)] }),
    B("ENGINEER / CREATOR", 1110, 35, 55, 720, C.line,
      { animate: [t("offsetX", 70, -60, 0, 4.1, "linear")] }),
    media({ file: portrait, x: 1090, y: 95, width: 735, height: 913, fit: "contain",
      animate: [t("offsetX", 300, 0, 0.12, 0.92),
        t("scale", 0.91, 1.045, 0.12, 3.98)] }),
    R(1174, 913, 606, 60, C.cyan, { radius: 8 }),
    M("PHNOM PENH / CAMBODIA", 1200, 930, 550, C.bg, { fontSize: 21 }),
    M("FULL STACK / AI ENGINEERING", 105, 106, 880, C.cyan,
      { animate: rise(0.08, 35) }),
    F("First name reveal", 91, 215, 990, 190, [
      B("RITHY", 0, 0, 198, 960, C.white,
        { motion: { by: "character", from: { y: 180, opacity: 0 },
          at: 0.08, duration: 0.47, overlap: 0.83, easing: "house" } }),
    ], { clip: true }),
    F("Surname reveal", 91, 416, 1030, 245, [
      B("BONDETH", 0, 0, 215, 1020, C.cyan,
        { motion: { by: "character", from: { y: 200, opacity: 0 },
          at: 0.23, duration: 0.48, overlap: 0.85, easing: "house" } }),
    ], { clip: true }),
    T("Full Stack Developer", 105, 705, 50, 960, C.white,
      { animate: rise(0.65, 70) }),
    T("& AI Engineer", 105, 775, 50, 960, C.white,
      { animate: rise(0.82, 70) }),
    R(105, 890, 720, 2, C.cyan, { animate: [t("scaleX", 0, 1, 0.65, 1.1)] }),
  ], 0, 4.18, "01 / The person");
  // A sharp numeral dominates the 3+ years beat; three lanes give it meaning.
  show(F("Experience", 0, 0, 1920, 1080, [
    M("01 / EXPERIENCE", 107, 90, 920, C.cyan, { animate: rise(0.12) }),
    B("3+", 68, 160, 585, 940, C.cyan, { animate: [
      t("offsetX", -350, 0, 0, 0.73), t("scale", 1.15, 1, 0, 0.73)] }),
    B("YEARS", 110, 755, 122, 800, C.white, { animate: rise(0.43) }),
    R(960, 200, 5, 640, C.line),
    T("Full Stack", 1030, 202, 94, 790, C.white, { animate: rise(0.28) }),
    T("Development", 1030, 314, 94, 820, C.white, { animate: rise(0.43) }),
    ...["WEB", "MOBILE", "AI"].map((word, i) => F(`Experience lane ${word}`,
      1030, 535 + i * 112, 780, 84, [
        R(0, 0, 780, 84, i === 1 ? "#12263d" : "#0e1a2a", { radius: 10 }),
        R(0, 0, 7, 84, i === 2 ? C.coral : C.cyan),
        B(word, 26, 12, 66, 380, C.white),
        M(i === 0 ? "Interfaces + APIs" : i === 1 ? "Cross-platform work" :
          "AI-powered products", 312, 30, 430, C.muted, { fontSize: 17 }),
      ], { animate: [t("offsetX", 730, 0, 0.55 + i * 0.17, 0.62),
        t("opacity", 0, 1, 0.55 + i * 0.17, 0.45)] })),
    M("FREELANCE  /  MANGO-BYTE  /  DEBC", 1014, 913, 820, C.muted,
      { fontSize: 17, animate: rise(1.2, 40) }),
  ], { animate: exit(4.05, -650) }), 4.22, 4.05, "02 / Three plus years");
  show(R(-1920, 0, 1920, 1080, C.cyan,
    { animate: [t("offsetX", 0, 3840, 0, 0.6)] }), 4.05, 0.6,
  "First full-frame wipe");
  for (let i = 0; i < 5; i++) show(R(-2100, 110 + i * 190, 2100, 13,
    i % 2 ? C.cyan : C.blue,
    { animate: [t("offsetX", 0, 4240, 0, 0.72 + i * 0.05)] }),
  7.98 + i * 0.035, 0.95, "Signal sweep into the stack");

  // Ten genuine technology marks converge from depth into a tool constellation.
  const tech = [
    ["react", "React", 170, 355], ["typescript", "TypeScript", 480, 355],
    ["nestjs", "NestJS", 790, 355], ["postgresql", "PostgreSQL", 1100, 355],
    ["flutter", "Flutter", 1410, 355], ["nextdotjs", "Next.js", 400, 635],
    ["python", "Python", 885, 635], ["swift", "Swift", 1370, 635],
    ["fastapi", "FastAPI", 685, 850], ["docker", "Docker", 1165, 850],
  ];
  show([
    M("02 / THE STACK", 105, 90, 800, C.cyan, { animate: rise(0.12) }),
    B("TOOLS THAT BECOME PRODUCTS", 105, 140, 128, 1720, C.white,
      { animate: rise(0.15, 110) }),
    M("SELECT A TOOL. TRACE THE DECISION. SEE THE RESULT.", 110, 303,
      1690, C.muted, { fontSize: 20, animate: rise(0.3) }),
  ], 8.22, 3.9, "03 / The stack");
  for (let i = 0; i < tech.length; i++) {
    const [slug, label, x, y] = tech[i];
    show(F(`Technology ${label}`, x, y, 150, 180, [
      R(0, 0, 150, 150, "#eaf0ed", { radius: 22 }),
      I(slug, 31, 30, 88),
      M(label, -34, 157, 218, C.white, { fontSize: 19, align: "center" }),
    ], { animate: [
      a("opacity", [k(0, 0), k(0.12 + i * 0.065, 0),
        k(0.55 + i * 0.065, 1), k(3.48, 1), k(3.98, 0)]),
      a("scale", [k(0, 0.24), k(0.7 + i * 0.065, 1), k(3.45, 1), k(3.98, 0.58)]),
      a("offsetX", [k(0, (i % 2 ? 1 : -1) * 350),
        k(0.72 + i * 0.065, 0), k(3.45, 0), k(3.98, 960 - x)]),
      a("offsetY", [k(0, i % 2 ? 240 : -240),
        k(0.72 + i * 0.065, 0), k(3.45, 0), k(3.98, 520 - y)]),
      a("rotation", [k(0, i % 2 ? 18 : -18),
        k(0.8 + i * 0.065, 0), k(3.45, 0), k(3.98, i % 2 ? -13 : 13)]),
    ] }), 8.2, 4.0, "Technology constellation");
  }

  // Each technology tile grows to fill the stage and reveals its case study.
  const chapter = ({ name, at, dur, x, y, slug, bg, accent, index, title,
    eyebrow, claim, metric, proof, image, next }) => show(F(name, x, y, 150, 150, [
    R(0, 0, 1920, 1080, bg),
    R(0, 0, 1920, 9, accent),
    R(0, 940, 1920, 2, "#26384b"),
    ...Array.from({ length: 5 }, (_, i) => L(0, 130 + i * 175, 1920, 130 + i * 175,
      "#213247")),
    F(`${name} origin icon`, 0, 0, 150, 150, [
      R(0, 0, 150, 150, C.white, { radius: 20 }), I(slug, 31, 30, 88),
    ], { animate: [a("opacity", [k(0, 1), k(0.58, 1), k(0.96, 0)]),
      a("scale", [k(0, 1), k(0.78, 2.2)])] }),
    F(`${name} content`, 0, 0, 1920, 1080, [
      M(`${index} / CASE STUDY`, 100, 86, 700, accent, { fontSize: 22 }),
      M(eyebrow, 100, 176, 1300, C.muted, { fontSize: 19 }),
      B(title[0], 89, 276, 155, 535, C.white),
      B(title[1], 89, 427, title[1].length > 8 ? 114 : 166, 535, accent),
      T(claim, 100, 635, 30, 475, C.white,
        { fontWeight: 400, lineHeight: 1.15 }),
      R(96, 800, 500, 135, "#152638", { radius: 10 }),
      B(metric, 118, 812, metric.length > 7 ? 80 : 105, 465, accent),
      M(proof, 117, 907, 470, C.muted, { fontSize: 17 }),
      F(`${name} preview`, 660, 181, 1180, 716, [
        R(0, 0, 1180, 716, C.white, { radius: 20 }),
        R(0, 0, 1180, 60, "#e2e9eb", { radius: 20 }),
        ...[accent, "#c7d1d7", "#9cabb7"].map((dot, i) =>
          R(22 + i * 30, 20, 13, 13, dot, { radius: 7 })),
        M("bondeth.dev / selected work", 168, 18, 760, "#354456",
          { fontSize: 16 }),
        media({ file: image, x: 22, y: 76, width: 1136, height: 608,
          fit: "contain", radius: 9,
          animate: [t("scale", 0.98, 1.035, 0, dur, "linear")] }),
      ], { clip: true, animate: [
        t("offsetX", 285, 0, 0.24, 0.78),
        t("rotation", 5, 0, 0.24, 0.78),
        t("scale", 0.86, 1, 0.24, 0.78),
      ] }),
      M("ENGINEERING IN PRACTICE  /  BONDETH.DEV", 100, 984, 1510,
        C.muted, { fontSize: 17 }),
      ...(next ? [F(`${name} next technology`, 1715, 68, 150, 150, [
        R(0, 0, 150, 150, C.white, { radius: 20 }), I(next, 31, 30, 88),
      ], { animate: [a("opacity", [k(0, 0), k(dur - 1.05, 0),
        k(dur - 0.68, 1)])] })] : []),
    ], { animate: [a("opacity", [k(0, 0), k(0.63, 0), k(1.08, 1)])] }),
  ], { clip: true, animate: [
    a("width", [k(0, 150), k(0.11, 150), k(0.81, 1920)]),
    a("height", [k(0, 150), k(0.11, 150), k(0.81, 1080)]),
    a("offsetX", [k(0, 0), k(0.11, 0), k(0.81, -x)]),
    a("offsetY", [k(0, 0), k(0.11, 0), k(0.81, -y)]),
  ] }), at, dur, name);

  chapter({ name: "04 / Next.js becomes Apsara Talent", at: 11.76, dur: 6.0,
    x: 400, y: 635, slug: "nextdotjs", bg: "#0b1928", accent: C.cyan,
    index: "01", title: ["APSARA", "TALENT"], eyebrow: "PEOPLE, NOT KEYWORDS",
    claim: "Match people by meaning with pgvector.", metric: "7 SERVICES",
    proof: "NestJS backend architecture", image: shots.talent, next: "python" });
  chapter({ name: "05 / Python becomes Apsara Assistant", at: 17.50, dur: 5.66,
    x: 1715, y: 68, slug: "python", bg: "#11172e", accent: C.blue,
    index: "02", title: ["APSARA", "ASSISTANT"], eyebrow: "REPLIES THAT UNDERSTAND CONTEXT",
    claim: "Khmer, English, and romanized Khmer across two channels.",
    metric: "3 MODES", proof: "Messenger + Telegram",
    image: shots.assistant, next: "swift" });
  chapter({ name: "06 / Swift becomes Bondex Notch", at: 22.92, dur: 4.62,
    x: 1715, y: 68, slug: "swift", bg: "#0a1c27", accent: C.coral,
    index: "03", title: ["BONDEX", "NOTCH"], eyebrow: "NATIVE MACOS. LIGHT ON RESOURCES.",
    claim: "Core Animation keeps the equaliser responsive.", metric: "3% CPU",
    proof: "From 12–14% while music plays", image: shots.notch });

  // Three screenshots converge behind a direct invitation to explore the work.
  show([
    R(0, 0, 1920, 1080, C.bg,
      { animate: [t("opacity", 0, 1, 0, 0.43)] }),
    ...["talent", "assistant", "notch"].map((name, i) => F(`Final ${name}`,
      1220 + i * 64, 260 + i * 88, 565, 370, [
        R(0, 0, 565, 370, C.white, { radius: 13 }),
        media({ file: shots[name], x: 12, y: 36, width: 541, height: 315,
          fit: "cover", radius: 7 }),
      ], { clip: true, animate: [
        t("offsetX", 730, 0, 0.08 + i * 0.11, 0.66),
        t("rotation", 0, (i - 1) * 12, 0.08 + i * 0.11, 0.66),
        t("opacity", 0, 1, 0.08 + i * 0.11, 0.38),
      ] })),
    M("PERSON. SKILL. PRODUCT.", 95, 105, 1180, C.cyan,
      { animate: rise(0.15, 35) }),
    B("MAKE THE", 87, 236, 185, 1130, C.white,
      { animate: rise(0.18, 95) }),
    B("NEXT THING", 87, 435, 185, 1190, C.cyan,
      { animate: rise(0.28, 95) }),
    T("Explore the case studies.", 101, 699, 45, 1050, C.white,
      { fontWeight: 400, animate: rise(0.43, 75) }),
    F("Final URL", 100, 804, 535, 105, [
      R(0, 0, 535, 105, C.cyan, { radius: 10 }),
      T("bondeth.dev", 39, 25, 49, 450, C.bg),
    ], { animate: rise(0.57, 60) }),
    M("RITHY BONDETH / FULL STACK DEVELOPER & AI ENGINEER", 100, 955,
      1560, C.muted, { fontSize: 17, animate: rise(0.72, 40) }),
  ], 27.27, 2.73, "07 / Explore the case studies");

  await p.frame(2.1, "renders/portfolio-showreel-v4-poster.png");
};

