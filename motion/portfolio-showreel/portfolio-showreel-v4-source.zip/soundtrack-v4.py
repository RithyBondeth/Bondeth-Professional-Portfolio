"""Original 30-second dark electronic cue, generated without borrowed samples."""
import math
import random
import struct
import wave
from pathlib import Path

RATE = 44_100
DURATION = 30
rng = random.Random(20261002)
samples = [0.0] * (RATE * DURATION)


def note(midi):
    return 440.0 * 2 ** ((midi - 69) / 12)


def add(start, length, synth, gain):
    offset = int(start * RATE)
    if offset >= len(samples):
        return
    for n in range(max(0, min(int(length * RATE), len(samples) - offset))):
        samples[offset + n] += synth(n / RATE) * gain


# C minor / A flat / E flat / B flat: broad low pad, with a pulsing bass ostinato.
chords = [(36, 39, 43), (32, 36, 39), (39, 43, 46), (34, 38, 41)]
for bar in range(15):
    chord = chords[(bar // 2) % len(chords)]
    for tone in chord:
        frequency = note(tone + 12)
        add(bar * 2, 2.0, lambda t, f=frequency: (
            math.sin(2 * math.pi * f * t)
            + 0.23 * math.sin(2 * math.pi * (f * 1.006) * t)
            + 0.09 * math.sin(2 * math.pi * 2 * f * t)
        ) * min(1.0, t / 0.24) * math.exp(-t / 2.4), 0.031)

    for beat in range(4):
        time = bar * 2 + beat * 0.5
        bass = note(chord[0] - 12)
        add(time, 0.43, lambda t, f=bass: math.sin(2 * math.pi * f * t)
            * math.exp(-t * 7), 0.15)
        add(time, 0.25, lambda t: math.sin(
            2 * math.pi * (48 * t + 52 * (1 - math.exp(-t * 28)) / 28)
        ) * math.exp(-t * 20), 0.23)
        if beat % 2:
            noise = [rng.uniform(-1, 1) for _ in range(int(RATE * 0.14))]
            add(time, 0.14, lambda t, data=noise: data[min(len(data) - 1,
                int(t * RATE))] * math.exp(-t * 30), 0.075)
        for step in range(2):
            moment = time + step * 0.25
            tone = chord[(beat + step) % 3] + 24
            frequency = note(tone)
            add(moment, 0.25, lambda t, f=frequency: (
                math.sin(2 * math.pi * f * t)
                + 0.2 * math.sin(2 * math.pi * f * 2.01 * t)
            ) * math.exp(-t * 14), 0.037)
            hat = [rng.uniform(-1, 1) for _ in range(int(RATE * 0.045))]
            add(moment, 0.045, lambda t, data=hat: data[min(len(data) - 1,
                int(t * RATE))] * math.exp(-t * 86), 0.02)


# Each main visual transformation has a noise swell and a low-frequency impact.
for cue in (4.05, 8.1, 11.76, 17.50, 22.92, 27.27):
    noise = [rng.uniform(-1, 1) for _ in range(int(RATE * 0.42))]
    add(cue - 0.36, 0.36, lambda t, data=noise: data[min(len(data) - 1,
        int(t * RATE))] * (t / 0.36) ** 2, 0.065)
    add(cue, 0.55, lambda t: math.sin(2 * math.pi * (49 * t +
        33 * (1 - math.exp(-t * 18)) / 18)) * math.exp(-t * 6), 0.18)

output = Path(__file__).with_name("soundtrack-v4.wav")
with wave.open(str(output), "wb") as stream:
    stream.setnchannels(2)
    stream.setsampwidth(2)
    stream.setframerate(RATE)
    pcm = bytearray()
    for i, sample in enumerate(samples):
        second = i / RATE
        fade = min(1.0, second / 0.3, (DURATION - second) / 0.8)
        value = int(math.tanh(sample * 1.2) * fade * 22500)
        pcm.extend(struct.pack("<hh", value, value))
    stream.writeframes(pcm)
print(output)

